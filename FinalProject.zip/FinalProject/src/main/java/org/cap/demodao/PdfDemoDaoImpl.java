package org.cap.demodao;

import org.cap.demo.pdfdto.PdfView;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class PdfDemoDaoImpl implements PdfDemoDao 
{
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public PdfView getCustomer(int order_id)
	{
	PdfView pdfView=(PdfView)sessionFactory.getCurrentSession().get(PdfView.class,order_id);
		
	return pdfView;
	}
	
	
}
