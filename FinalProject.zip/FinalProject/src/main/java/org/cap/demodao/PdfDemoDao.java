package org.cap.demodao;

import org.cap.demo.pdfdto.PdfView;

public interface PdfDemoDao 
{
	public PdfView getCustomer(int order_id);
	
}
