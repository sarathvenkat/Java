package org.cap.demo.pdf;



import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import org.cap.demo.pdfdto.PdfView;
import org.cap.demoservice.ServicePdf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;


@Controller
public class PdfDemoController 
{
    @Autowired
    private ServicePdf servicepdf;
	
	
	@RequestMapping("/welcome")
	public String welcomeFile(ModelMap map)
	{
		map.put("pdfdemo", new PdfView());
		
		return "pdfViewer";
	}
	
	
	@RequestMapping(value="/pdfViewer",method=RequestMethod.POST)
	public String pdfGeneration(@ModelAttribute("pdfdemo") PdfView pdfview)
	{
		System.out.println(" hello Controller How are you ? ");
				
		PdfView pdfView=servicepdf.getCustomer(pdfview.getOrder_Id());
		
		System.out.println(pdfView); 
		
		Document document=new Document();
		
		try
		{
			PdfWriter pdfwriter=PdfWriter.getInstance(document, new FileOutputStream("D:\\helloPdf.pdf"));
			document.open();
			document.add(new Paragraph(pdfView.toString()));
			 document.close();
			 pdfwriter.close();
		
		}
		catch (FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (DocumentException e)
		{
			e.printStackTrace();
		}
		
		return "pdfViewer";
	}

	
	
}
