package org.cap.demo.pdfdto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pdf_View")
public class PdfView 
{
	
	@Id
	@GeneratedValue
	private int order_Id; 
	@Column(nullable=false)
	private String product_name;
    @Column(nullable=false)
	private String cust_name;
    
    
    public PdfView(){}
    
	public PdfView(int order_Id, String product_name, String cust_name) {
		super();
		this.order_Id = order_Id;
		this.product_name = product_name;
		this.cust_name = cust_name;
	}
	
	public int getOrder_Id() 
	{
		return order_Id;
	}
	public void setOrder_Id(int order_Id) 
	{
		this.order_Id = order_Id;
	}
	public String getProduct_name()
	{
		return product_name;
	}
	public void setProduct_name(String product_name)
	{
		this.product_name = product_name;
	}
	public String getCust_name() 
	{
		return cust_name;
	}
	public void setCust_name(String cust_name) 
	{
		this.cust_name = cust_name;
	}

	@Override
	public String toString() 
	{
		return "PdfView [order_Id=" + order_Id + ", product_name=" + product_name + ", cust_name=" + cust_name + "]";
	}
	
    	
}
