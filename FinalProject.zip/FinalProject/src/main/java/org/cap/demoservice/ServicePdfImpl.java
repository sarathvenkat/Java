package org.cap.demoservice;

import org.cap.demo.pdfdto.PdfView;
import org.cap.demodao.PdfDemoDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ServicePdfImpl implements ServicePdf
{
    @Autowired
	private PdfDemoDao ipdfdemo;
	
    @Transactional
	public PdfView getCustomer(int order_id)
	{
		return ipdfdemo.getCustomer(order_id);
	}
	
}
