package org.cap.demoservice;

import org.cap.demo.pdfdto.PdfView;

public interface ServicePdf 
{
	public PdfView getCustomer(int order_id);
	
}
