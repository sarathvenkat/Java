app.controller('myCtrl',function($scope)
{
//alert("hi");
$scope.changeSrcPath=function(id)
{
//alert(id);

if(id=='add')
{
//alert("matches");
$scope.myUrl="addCustomer.html";
}

else if(id=='update')
{
$scope.myUrl="updateCustomer.html";
}

else if(id=='delete')
{
$scope.myUrl="deleteCustomer.html";
}

else
{
$scope.myUrl="viewCustomer.html";
}

}


$scope.myArray=[];

$scope.myAddCustomerSubmit=function()
{



$scope.userData={firstname:' ',lastname:' ',dateofbirth:'',email:''};

alert($scope.firstname+" "+$scope.lastname+" "+$scope.dateofbirth+" "+$scope.email);

$scope.userData.firstname=$scope.firstname;
$scope.userData.lastname=$scope.lastname;
$scope.userData.dateofbirth=$scope.dateofbirth;
$scope.userData.email=$scope.email;

$scope.myArray.push($scope.userData);

}






//Controller Ending
});






app.controller('myUpdateCustomer',function($scope)
{

//alert("Hello");






});