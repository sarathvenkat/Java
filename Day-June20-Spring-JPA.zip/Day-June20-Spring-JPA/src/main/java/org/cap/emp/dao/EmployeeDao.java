package org.cap.emp.dao;

import java.util.List;

import org.cap.emp.dto.Employee;

public interface EmployeeDao {
	public void saveEmployee(Employee employee);
	
	public List<Employee> getAllEmployees();
	
	public void deleteEmployee(Integer employeeId);
}
